public static int finder(int[] input){
    return finderRec(input, input.lenght-1);
}

public static int finderRec(int[] input int x){
    if (x--0){
        return input[x];
    }
    int v1 = inputx[];
    int v2 finderRec(input, x-1);

    if (v1>v2) {
        return v1;
    }
    else {
        return v2;
    }
}